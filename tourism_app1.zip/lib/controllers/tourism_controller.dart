import '../models/destination_model.dart';
import '../models/category_model.dart';

class TourismController {
  static final List<DestinationModel> _allDestinations = [
    DestinationModel(
      id: 1,
      name: 'Petra',
      country: 'Jordan',
      description: 'The ancient rose-red city carved into rock cliffs.',
      fullDescription:
          'Petra is a famous archaeological site in southern Jordan, known for its rock-cut architecture and water conduit system. It is one of the New Seven Wonders of the World and was the capital of the Nabataean Kingdom. The site features tombs, temples, and the iconic Treasury (Al-Khazneh) carved directly into sandstone cliffs that glow rose-red at sunset. Visitors can explore over 800 individual monuments across the 264 km² site.',
      imageAsset: 'assets/images/placeholder.png',
      networkImage:
          'https://upload.wikimedia.org/wikipedia/commons/thumb/1/10/Treasury_petra_crop.jpg/800px-Treasury_petra_crop.jpg',
      category: 'Historical',
      rating: 5.0,
      bestTime: 'March – May',
      mapUrl: 'https://maps.google.com/?q=Petra,Jordan',
      isSaved: true,
    ),
    DestinationModel(
      id: 2,
      name: 'Santorini',
      country: 'Greece',
      description: 'Iconic white-washed villages above the blue Aegean Sea.',
      fullDescription:
          'Santorini is a volcanic island in the Cyclades group of the Greek islands. It is famous for dramatic views, stunning sunsets from Oia town, the submerged caldera, and its very own active volcano. The island offers black sand beaches and whitewashed blue-domed churches. The unique landscape was shaped by one of the largest volcanic eruptions in history and draws millions of visitors each year for its breathtaking panoramas.',
      imageAsset: 'assets/images/placeholder.png',
      networkImage:
          'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Thira%2C_Santorini%2C_Greece.jpg/800px-Thira%2C_Santorini%2C_Greece.jpg',
      category: 'Beach',
      rating: 4.8,
      bestTime: 'June – September',
      mapUrl: 'https://maps.google.com/?q=Santorini,Greece',
    ),
    DestinationModel(
      id: 3,
      name: 'Machu Picchu',
      country: 'Peru',
      description: 'The legendary Incan citadel high in the Andes mountains.',
      fullDescription:
          'Machu Picchu is a 15th-century Inca citadel located in the Eastern Cordillera of southern Peru on a 2,430-meter mountain ridge. It is the most familiar icon of Inca civilization, often referred to as the Lost City of the Incas. The site features dry-stone walls fused with huge blocks without mortar, and intriguing buildings that play on astronomical alignments. It was designated a UNESCO World Heritage Site in 1983.',
      imageAsset: 'assets/images/placeholder.png',
      networkImage:
          'https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Machu_Picchu%2C_Peru.jpg/800px-Machu_Picchu%2C_Peru.jpg',
      category: 'Historical',
      rating: 4.9,
      bestTime: 'April – October',
      mapUrl: 'https://maps.google.com/?q=Machu+Picchu,Peru',
    ),
    DestinationModel(
      id: 4,
      name: 'Maldives',
      country: 'Maldives',
      description: 'Crystal-clear waters and overwater bungalows in paradise.',
      fullDescription:
          'The Maldives is a small island nation in the Indian Ocean consisting of about 1,190 coral islands grouped in 26 atolls. It is the world\'s lowest country. The Maldives offers world-class diving and snorkelling, pristine white sand beaches, and some of the most luxurious overwater bungalows on earth. The coral reefs are home to a stunning variety of marine life including whale sharks and manta rays.',
      imageAsset: 'assets/images/placeholder.png',
      networkImage:
          'https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/Maldives_from_the_air.jpg/800px-Maldives_from_the_air.jpg',
      category: 'Beach',
      rating: 4.9,
      bestTime: 'November – April',
      mapUrl: 'https://maps.google.com/?q=Maldives',
    ),
    DestinationModel(
      id: 5,
      name: 'Swiss Alps',
      country: 'Switzerland',
      description: 'Majestic mountain peaks, glaciers, and alpine villages.',
      fullDescription:
          'The Swiss Alps cover most of the southern part of Switzerland. The region features some of Europe\'s highest peaks including the Matterhorn and Jungfrau. It offers world-class skiing in winter, breathtaking hiking trails in summer, and charming villages year-round. The Jungfraujoch, known as the Top of Europe, is accessible by the highest railway station in Europe at 3,454 meters above sea level.',
      imageAsset: 'assets/images/placeholder.png',
      networkImage:
          'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/Matterhorn_from_Zermatt.jpg/800px-Matterhorn_from_Zermatt.jpg',
      category: 'Adventure',
      rating: 4.8,
      bestTime: 'December – March',
      mapUrl: 'https://maps.google.com/?q=Swiss+Alps,Switzerland',
    ),
    DestinationModel(
      id: 6,
      name: 'Kyoto',
      country: 'Japan',
      description: 'Ancient temples, geisha districts, and bamboo forests.',
      fullDescription:
          'Kyoto served as Japan\'s capital and the emperor\'s residence from 794 until 1869. It now has a population of 1.5 million. Thousands of classical Buddhist temples, Shinto shrines, gardens and imperial villas still exist in the city. Famous sites include the golden pavilion Kinkaku-ji, the Fushimi Inari shrine with thousands of torii gates, and the Arashiyama bamboo grove. The city is particularly stunning during cherry blossom season in spring.',
      imageAsset: 'assets/images/placeholder.png',
      networkImage:
          'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Fushimi_Inari-taisha.jpg/800px-Fushimi_Inari-taisha.jpg',
      category: 'Cultural',
      rating: 4.9,
      bestTime: 'March – May',
      mapUrl: 'https://maps.google.com/?q=Kyoto,Japan',
    ),
    DestinationModel(
      id: 7,
      name: 'Sahara Desert',
      country: 'Morocco',
      description: 'Endless golden sand dunes under star-filled skies.',
      fullDescription:
          'The Sahara is the world\'s largest hot desert. The Moroccan Sahara, accessible from Merzouga, offers spectacular sand dunes including Erg Chebbi reaching 150 meters high. Visitors can experience camel trekking, overnight stays in traditional Berber camps under millions of stars, and spectacular sunrises that paint the dunes in shades of orange and gold.',
      imageAsset: 'assets/images/placeholder.png',
      networkImage:
          'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Djanet-erg-admer.jpg/800px-Djanet-erg-admer.jpg',
      category: 'Adventure',
      rating: 4.7,
      bestTime: 'October – April',
      mapUrl: 'https://maps.google.com/?q=Sahara+Desert,Morocco',
    ),
    DestinationModel(
      id: 8,
      name: 'Wadi Rum',
      country: 'Jordan',
      description: 'Mars-like desert valleys with ancient rock inscriptions.',
      fullDescription:
          'Wadi Rum, also known as the Valley of the Moon, is a protected desert wilderness in southern Jordan. It features dramatic sandstone mountains and echoing valleys of red sand. The area has been inhabited by many human cultures since prehistoric times, leaving numerous rock drawings and inscriptions. It was the backdrop for filming The Martian due to its alien landscape. Visitors can experience Bedouin culture, jeep tours, and world-class rock climbing.',
      imageAsset: 'assets/images/placeholder.png',
      networkImage:
          'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Wadi_Rum_-_Wadi_Um_Ishrin.jpg/800px-Wadi_Rum_-_Wadi_Um_Ishrin.jpg',
      category: 'Adventure',
      rating: 4.8,
      bestTime: 'September – May',
      mapUrl: 'https://maps.google.com/?q=Wadi+Rum,Jordan',
    ),
  ];

  static final List<CategoryModel> _allCategories = [
    CategoryModel(id: 'all', name: 'All', icon: '🌍', color: '0xFF2196F3'),
    CategoryModel(id: 'beach', name: 'Beach', icon: '🏖️', color: '0xFF00BCD4'),
    CategoryModel(
        id: 'historical', name: 'Historical', icon: '🏛️', color: '0xFF795548'),
    CategoryModel(
        id: 'adventure', name: 'Adventure', icon: '🏔️', color: '0xFF4CAF50'),
    CategoryModel(
        id: 'cultural', name: 'Cultural', icon: '🎎', color: '0xFF9C27B0'),
  ];

  static List<DestinationModel> get allDestinations =>
      List.unmodifiable(_allDestinations);

  static List<CategoryModel> get allCategories =>
      List.unmodifiable(_allCategories);

  static List<DestinationModel> filterByCategory(String categoryId) {
    if (categoryId == 'all') return _allDestinations;
    return _allDestinations
        .where((d) => d.category.toLowerCase() == categoryId.toLowerCase())
        .toList();
  }

  static List<DestinationModel> search(String query) {
    final q = query.toLowerCase();
    return _allDestinations
        .where((d) =>
            d.name.toLowerCase().contains(q) ||
            d.country.toLowerCase().contains(q) ||
            d.category.toLowerCase().contains(q))
        .toList();
  }

  static List<DestinationModel> getSaved() {
    return _allDestinations.where((d) => d.isSaved).toList();
  }

  static void toggleSaved(int id) {
    final index = _allDestinations.indexWhere((d) => d.id == id);
    if (index != -1) {
      _allDestinations[index].isSaved = !_allDestinations[index].isSaved;
    }
  }

  static DestinationModel? getById(int id) {
    try {
      return _allDestinations.firstWhere((d) => d.id == id);
    } catch (_) {
      return null;
    }
  }

  static String formatRating(double rating) {
    return rating.toStringAsFixed(1);
  }
}
