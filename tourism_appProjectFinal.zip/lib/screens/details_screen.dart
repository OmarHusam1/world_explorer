import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/destination_model.dart';
import '../controllers/tourism_controller.dart';

class DetailsScreen extends StatefulWidget {
  final DestinationModel destination;

  const DetailsScreen({super.key, required this.destination});

  @override
  State<DetailsScreen> createState() => _DetailsScreenState();
}

class _DetailsScreenState extends State<DetailsScreen> {
  late bool _isSaved;
  final _controller = TourismController();

  static const Color _primary = Color(0xFFD4AF37);
  @override
  void initState() {
    super.initState();
    _isSaved = widget.destination.isSaved;
  }

  Future<void> _openMap() async {
    final uri = Uri.parse(widget.destination.mapUrl);
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open maps')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final dest = widget.destination;

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: CustomScrollView(
        slivers: [
          // ── Hero image ────────────────────────────────────────────────
          SliverAppBar(
            expandedHeight: 340,
            pinned: true,
            backgroundColor: const Color(0xFF0A0A0A),
            iconTheme: const IconThemeData(color: Colors.white),
            leading: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.5),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.arrow_back_ios_new_rounded,
                    color: Colors.white, size: 16),
              ),
            ),
            actions: [
              GestureDetector(
                onTap: () {
                  _controller.toggleSaved(dest.id);
                  setState(() => _isSaved = !_isSaved);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      backgroundColor: const Color(0xFF1A1A1A),
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                      content: Text(
                        _isSaved
                            ? '${dest.name} added to wishlist ❤️'
                            : '${dest.name} removed',
                        style: GoogleFonts.dmSans(color: Colors.white),
                      ),
                      duration: const Duration(seconds: 2),
                    ),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.all(8),
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    _isSaved
                        ? Icons.favorite_rounded
                        : Icons.favorite_border_rounded,
                    color: _isSaved ? const Color(0xFFFFD700) : Colors.white,
                    size: 20,
                  ),
                ),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    dest.networkImage,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: const Color(0xFF2A2A2A),
                      child: const Icon(Icons.image, size: 80),
                    ),
                  ),
                  // gradient overlay
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withOpacity(0.6),
                          Colors.black.withOpacity(0.7),
                        ],
                        stops: const [0.4, 1.0],
                      ),
                    ),
                  ),
                  // destination name overlay
                  Positioned(
                    bottom: 24,
                    left: 20,
                    right: 20,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: _primary.withOpacity(0.9),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            dest.category,
                            style: GoogleFonts.dmSans(
                              color: Colors.black,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          dest.name,
                          style: GoogleFonts.cormorantGaramond(
                            color: Colors.white,
                            fontSize: 32,
                            fontWeight: FontWeight.w700,
                            height: 1.1,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            const Icon(Icons.location_on_rounded,
                                color: Color(0xFFFFD700), size: 15),
                            const SizedBox(width: 3),
                            Text(
                              dest.country,
                              style: GoogleFonts.dmSans(
                                  color: Colors.white70, fontSize: 14),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Content ───────────────────────────────────────────────────
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // quick info chips
                  Row(
                    children: [
                      _InfoBadge(
                        emoji: '⭐',
                        label:
                            '${TourismController.formatRating(dest.rating)} Rating',
                        color: const Color(0xFF1A1500),
                        textColor: const Color(0xFFFFD700),
                      ),
                      const SizedBox(width: 10),
                      _InfoBadge(
                        emoji: '🌤️',
                        label: dest.bestTime,
                        color: const Color(0xFF1A1A0A),
                        textColor: const Color(0xFFD4AF37),
                      ),
                    ],
                  ),

                  const SizedBox(height: 28),

                  // About section
                  _SectionLabel(title: 'About'),
                  const SizedBox(height: 10),
                  Text(
                    dest.fullDescription,
                    style: GoogleFonts.dmSans(
                      fontSize: 14,
                      color: const Color(0xFFAAAAAA),
                      height: 1.85,
                    ),
                  ),

                  const SizedBox(height: 28),

                  // Gallery
                  _SectionLabel(title: 'Gallery'),
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Image.network(
                      dest.networkImage,
                      width: double.infinity,
                      height: 210,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(
                        height: 210,
                        color: const Color(0xFF1E1E1E),
                        child: const Icon(Icons.broken_image,
                            size: 60, color: const Color(0xFF666666)),
                      ),
                    ),
                  ),

                  const SizedBox(height: 28),

                  // Quick Facts
                  _SectionLabel(title: 'Quick Facts'),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFF161616),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.4),
                          blurRadius: 16,
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        _FactRow(label: 'Country', value: dest.country),
                        _Divider(),
                        _FactRow(label: 'Category', value: dest.category),
                        _Divider(),
                        _FactRow(label: 'Best Time', value: dest.bestTime),
                        _Divider(),
                        _FactRow(
                          label: 'Rating',
                          value: '${dest.rating} / 5.0  ${dest.ratingStars}',
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 28),

                  // Map button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _openMap,
                      icon: const Icon(Icons.map_outlined, size: 20),
                      label: Text(
                        'Open in Google Maps',
                        style: GoogleFonts.dmSans(
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFD4AF37),
                        foregroundColor: const Color(0xFF161616),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16)),
                        elevation: 0,
                      ),
                    ),
                  ),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String title;
  const _SectionLabel({required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 20,
          decoration: BoxDecoration(
            color: const Color(0xFFD4AF37),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: GoogleFonts.cormorantGaramond(
            fontSize: 22,
            fontWeight: FontWeight.w700,
            color: const Color(0xFFF5F0E8),
          ),
        ),
      ],
    );
  }
}

class _InfoBadge extends StatelessWidget {
  final String emoji;
  final String label;
  final Color color;
  final Color textColor;

  const _InfoBadge({
    required this.emoji,
    required this.label,
    required this.color,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 14)),
          const SizedBox(width: 6),
          Text(
            label,
            style: GoogleFonts.dmSans(
              color: textColor,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _FactRow extends StatelessWidget {
  final String label;
  final String value;

  const _FactRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: GoogleFonts.dmSans(
                color: const Color(0xFF888888), fontSize: 13),
          ),
          Text(
            value,
            style: GoogleFonts.dmSans(
              fontWeight: FontWeight.w600,
              fontSize: 13,
              color: const Color(0xFFF5F0E8),
            ),
          ),
        ],
      ),
    );
  }
}

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Divider(height: 1, color: const Color(0xFF1A1A1A));
  }
}
