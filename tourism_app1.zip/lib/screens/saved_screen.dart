import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../controllers/tourism_controller.dart';
import '../widgets/destination_card.dart';
import 'details_screen.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  @override
  Widget build(BuildContext context) {
    final savedList = TourismController.getSaved();

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A1A2E),
        automaticallyImplyLeading: false,
        title: Text(
          'Saved Places',
          style: GoogleFonts.playfairDisplay(
              color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: savedList.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('🔖', style: TextStyle(fontSize: 60)),
                  const SizedBox(height: 16),
                  Text(
                    'No saved destinations yet',
                    style: GoogleFonts.poppins(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF1A1A2E)),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Tap the bookmark icon on any\ndestination to save it here.',
                    textAlign: TextAlign.center,
                    style:
                        GoogleFonts.poppins(color: Colors.grey, fontSize: 14),
                  ),
                ],
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.only(top: 10, bottom: 20),
              itemCount: savedList.length,
              itemBuilder: (context, index) {
                final dest = savedList[index];
                return DestinationCard(
                  destination: dest,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => DetailsScreen(destination: dest)),
                    ).then((_) => setState(() {}));
                  },
                  onSaveToggle: () {
                    TourismController.toggleSaved(dest.id);
                    setState(() {});
                  },
                );
              },
            ),
    );
  }
}
