import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../controllers/tourism_controller.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF1A1A2E), Color(0xFF0F3460)],
                ),
                borderRadius:
                    BorderRadius.vertical(bottom: Radius.circular(30)),
              ),
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + 20,
                bottom: 30,
                left: 20,
                right: 20,
              ),
              child: Column(
                children: [
                  Container(
                    width: 90,
                    height: 90,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                    ),
                    child: const Center(
                      child: Text('✈️', style: TextStyle(fontSize: 40)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Explorer Profile',
                    style: GoogleFonts.playfairDisplay(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold),
                  ),
                  Text(
                    'Travel enthusiast & adventure seeker',
                    style: GoogleFonts.poppins(
                        color: Colors.white70, fontSize: 13),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      _ProfileStat(
                          value: '${TourismController.allDestinations.length}',
                          label: 'Destinations'),
                      _ProfileStat(
                          value: '${TourismController.getSaved().length}',
                          label: 'Saved'),
                      const _ProfileStat(value: '4', label: 'Categories'),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('About This App',
                      style: GoogleFonts.playfairDisplay(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF1A1A2E))),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 10)
                      ],
                    ),
                    child: Text(
                      'World Explorer is a tourism guide app built with Flutter. '
                      'Discover amazing destinations around the globe, filter by category, '
                      'search for your dream location, and save your favorites for later.',
                      style: GoogleFonts.poppins(
                          color: Colors.grey[700], fontSize: 13, height: 1.8),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text('Features',
                      style: GoogleFonts.playfairDisplay(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF1A1A2E))),
                  const SizedBox(height: 12),
                  ...[
                    ('🌍', 'Browse destinations worldwide'),
                    ('🔍', 'Search by name, country, or type'),
                    ('🏷️', 'Filter by category'),
                    ('🔖', 'Save your favorite destinations'),
                    ('🗺️', 'Open locations in Google Maps'),
                    ('⭐', 'Ratings and travel info'),
                  ].map((item) => Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                                color: Colors.black.withOpacity(0.04),
                                blurRadius: 6)
                          ],
                        ),
                        child: Row(
                          children: [
                            Text(item.$1, style: const TextStyle(fontSize: 20)),
                            const SizedBox(width: 12),
                            Text(item.$2,
                                style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    color: const Color(0xFF1A1A2E))),
                          ],
                        ),
                      )),
                  const SizedBox(height: 20),
                  Text('Built With',
                      style: GoogleFonts.playfairDisplay(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xFF1A1A2E))),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      'Flutter',
                      'Dart',
                      'google_fonts',
                      'url_launcher',
                      'MVC Architecture',
                      'OOP Concepts',
                    ]
                        .map((tech) => Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: const Color(0xFF1A1A2E),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(tech,
                                  style: GoogleFonts.poppins(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500)),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileStat extends StatelessWidget {
  final String value;
  final String label;

  const _ProfileStat({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value,
            style: GoogleFonts.poppins(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold)),
        Text(label,
            style: GoogleFonts.poppins(color: Colors.white70, fontSize: 12)),
      ],
    );
  }
}
