import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../controllers/tourism_controller.dart';
import '../models/destination_model.dart';
import 'details_screen.dart';

class SavedScreen extends StatefulWidget {
  const SavedScreen({super.key});

  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  final _controller = TourismController();

  static const Color _primary = Color(0xFFD4AF37);
  static const Color _bg = Color(0xFF0A0A0A);
  static const Color _dark = Color(0xFFF5F0E8);

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onControllerChange);
  }

  void _onControllerChange() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _controller.removeListener(_onControllerChange);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final savedList = _controller.getSaved();

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Column(
        children: [
          // ── Header ───────────────────────────────────────────────────
          Container(
            width: double.infinity,
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 16,
              bottom: 20,
              left: 24,
              right: 24,
            ),
            decoration: const BoxDecoration(
              color: _primary,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'My Wishlist',
                      style: GoogleFonts.cormorantGaramond(
                        color: const Color(0xFF161616),
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      savedList.isEmpty
                          ? 'Start saving places!'
                          : '${savedList.length} place${savedList.length != 1 ? 's' : ''} saved',
                      style: GoogleFonts.dmSans(
                        color: Colors.white.withOpacity(0.75),
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.12),
                    shape: BoxShape.circle,
                  ),
                  child: const Center(
                    child: Text('❤️', style: TextStyle(fontSize: 22)),
                  ),
                ),
              ],
            ),
          ),

          // ── Content ──────────────────────────────────────────────────
          Expanded(
            child: savedList.isEmpty
                ? _EmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 20),
                    itemCount: savedList.length,
                    itemBuilder: (context, index) {
                      final dest = savedList[index];
                      return _SavedTile(
                        destination: dest,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DetailsScreen(destination: dest),
                          ),
                        ),
                        onRemove: () => _controller.toggleSaved(dest.id),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              color: const Color(0xFFD4AF37).withOpacity(0.08),
              shape: BoxShape.circle,
            ),
            child: const Center(
              child: Text('🗺️', style: TextStyle(fontSize: 44)),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Nothing saved yet',
            style: GoogleFonts.cormorantGaramond(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              color: const Color(0xFFF5F0E8),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Tap ❤️ on any destination\nto add it to your wishlist.',
            textAlign: TextAlign.center,
            style: GoogleFonts.dmSans(
              color: const Color(0xFF666666),
              fontSize: 14,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}

class _SavedTile extends StatelessWidget {
  final DestinationModel destination;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  const _SavedTile({
    required this.destination,
    required this.onTap,
    required this.onRemove,
  });

  static const Color _primary = Color(0xFFD4AF37);
  static const Color _accent = Color(0xFFFFD700);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF161616),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            // image
            ClipRRect(
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                bottomLeft: Radius.circular(20),
              ),
              child: Image.network(
                destination.networkImage,
                width: 100,
                height: 100,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  width: 100,
                  height: 100,
                  color: const Color(0xFF1E1E1E),
                  child: const Icon(Icons.image_not_supported,
                      color: const Color(0xFF666666)),
                ),
              ),
            ),
            // info
            Expanded(
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // category badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: _primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        destination.category,
                        style: GoogleFonts.dmSans(
                          color: _primary,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.4,
                        ),
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      destination.name,
                      style: GoogleFonts.cormorantGaramond(
                        fontSize: 17,
                        fontWeight: FontWeight.w700,
                        color: const Color(0xFFF5F0E8),
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Icon(Icons.location_on_rounded,
                            color: _primary, size: 12),
                        const SizedBox(width: 3),
                        Text(
                          destination.country,
                          style: GoogleFonts.dmSans(
                              color: const Color(0xFF666666), fontSize: 12),
                        ),
                        const Spacer(),
                        const Icon(Icons.star_rounded,
                            color: Color(0xFFFFD700), size: 13),
                        const SizedBox(width: 2),
                        Text(
                          destination.rating.toString(),
                          style: GoogleFonts.dmSans(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFFF5F0E8),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            // remove button
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: GestureDetector(
                onTap: onRemove,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFD700).withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.favorite_rounded,
                      color: Color(0xFFFFD700), size: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
