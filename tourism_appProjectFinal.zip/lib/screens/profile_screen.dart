import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../controllers/tourism_controller.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _controller = TourismController();

  static const Color _primary = Color(0xFFD4AF37);
  static const Color _accent = Color(0xFFFFD700);
  static const Color _dark = Color(0xFFF5F0E8);

  @override
  void initState() {
    super.initState();
    _controller.addListener(_onControllerChange);
  }

  void _onControllerChange() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _controller.removeListener(_onControllerChange);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header card ────────────────────────────────────────────
            Stack(
              clipBehavior: Clip.none,
              children: [
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.only(
                    top: MediaQuery.of(context).padding.top + 20,
                    bottom: 50,
                    left: 24,
                    right: 24,
                  ),
                  decoration: const BoxDecoration(
                    color: _primary,
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(40),
                      bottomRight: Radius.circular(40),
                    ),
                  ),
                  child: CustomPaint(
                    painter: _DotPatternPainter(),
                    child: Column(
                      children: [
                        // avatar
                        Container(
                          width: 86,
                          height: 86,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xFF161616),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.6), width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.6),
                                blurRadius: 20,
                                offset: const Offset(0, 6),
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Icon(
                              Icons.flight,
                              color: Color(0xFFD4AF37),
                              size: 40,
                            ),
                          ),
                        ),
                        const SizedBox(height: 14),
                        Text(
                          'World Explorer',
                          style: GoogleFonts.cormorantGaramond(
                            color: const Color(0xFF161616),
                            fontSize: 26,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Travel enthusiast & adventure seeker',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.dmSans(
                            color: Colors.black.withOpacity(0.55),
                            fontSize: 13,
                          ),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                ),
                // floating stats bar
                Positioned(
                  bottom: -28,
                  left: 24,
                  right: 24,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        vertical: 18, horizontal: 10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF161616),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: _primary.withOpacity(0.15),
                          blurRadius: 24,
                          offset: const Offset(0, 8),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _StatItem(
                          value: '${_controller.allDestinations.length}',
                          label: 'Destinations',
                          color: _primary,
                        ),
                        _Divider(),
                        _StatItem(
                          value: '${_controller.getSaved().length}',
                          label: 'Saved',
                          color: const Color(0xFFFFD700),
                        ),
                        _Divider(),
                        _StatItem(
                          value:
                              '${TourismController.allCategories.length - 1}',
                          label: 'Categories',
                          color: _accent,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 52),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── About ──────────────────────────────────────────────
                  _SectionTitle(title: 'About This App'),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: const Color(0xFF161616),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                    child: Text(
                      'World Explorer is a tourism guide app built with Flutter. '
                      'Discover amazing destinations around the globe, filter by category, '
                      'search for your dream location, and save your favorites for later.',
                      style: GoogleFonts.dmSans(
                        color: const Color(0xFFAAAAAA),
                        fontSize: 14,
                        height: 1.75,
                      ),
                    ),
                  ),

                  const SizedBox(height: 28),

                  // ── Features ───────────────────────────────────────────
                  _SectionTitle(title: 'Features'),
                  const SizedBox(height: 12),
                  ...[
                    {'icon': '🌍', 'text': 'Browse destinations worldwide'},
                    {'icon': '🔍', 'text': 'Search by name, country, or type'},
                    {'icon': '🏷️', 'text': 'Filter by category'},
                    {'icon': '❤️', 'text': 'Save your favourite destinations'},
                    {'icon': '🗺️', 'text': 'Open locations in Google Maps'},
                    {'icon': '⭐', 'text': 'Ratings and travel info'},
                  ].map(
                    (item) => Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        color: const Color(0xFF161616),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: const Color(0xFF2A2A2A),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Center(
                              child: Text(item['icon']!,
                                  style: const TextStyle(fontSize: 18)),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Text(
                            item['text']!,
                            style: GoogleFonts.dmSans(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: _dark,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 28),

                  // ── Built With ─────────────────────────────────────────
                  _SectionTitle(title: 'Built With'),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      'Flutter',
                      'Dart',
                      'google_fonts',
                      'url_launcher',
                      'MVC Architecture',
                      'OOP Concepts',
                    ]
                        .map(
                          (tech) => Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 8),
                            decoration: BoxDecoration(
                              color: _primary.withOpacity(0.09),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                  color: _primary.withOpacity(0.25), width: 1),
                            ),
                            child: Text(
                              tech,
                              style: GoogleFonts.dmSans(
                                color: _primary,
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                  ),

                  const SizedBox(height: 40),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DotPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.06)
      ..style = PaintingStyle.fill;
    const spacing = 22.0;
    for (double x = 0; x < size.width; x += spacing) {
      for (double y = 0; y < size.height; y += spacing) {
        canvas.drawCircle(Offset(x, y), 1.5, paint);
      }
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 20,
          decoration: BoxDecoration(
            color: const Color(0xFFD4AF37),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: GoogleFonts.cormorantGaramond(
            fontSize: 22,
            fontWeight: FontWeight.w700,
            color: const Color(0xFFF5F0E8),
          ),
        ),
      ],
    );
  }
}

class _StatItem extends StatelessWidget {
  final String value;
  final String label;
  final Color color;

  const _StatItem(
      {required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: GoogleFonts.cormorantGaramond(
            fontSize: 24,
            fontWeight: FontWeight.w700,
            color: color,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style:
              GoogleFonts.dmSans(fontSize: 11, color: const Color(0xFF888888)),
        ),
      ],
    );
  }
}

class _Divider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(width: 1, height: 36, color: const Color(0xFF2A2A2A));
  }
}
