import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../controllers/tourism_controller.dart';
import '../models/destination_model.dart';
import 'details_screen.dart';

class DestinationsScreen extends StatefulWidget {
  final String initialCategory;
  final bool showBackButton;

  const DestinationsScreen({
    super.key,
    this.initialCategory = 'all',
    this.showBackButton = false,
  });

  @override
  State<DestinationsScreen> createState() => _DestinationsScreenState();
}

class _DestinationsScreenState extends State<DestinationsScreen> {
  late String _selectedCategory;
  List<DestinationModel> _displayedList = [];
  final TextEditingController _searchController = TextEditingController();
  bool _isSearching = false;
  final _controller = TourismController();

  static const Color _primary = Color(0xFFD4AF37);

  @override
  void initState() {
    super.initState();
    _selectedCategory = widget.initialCategory;
    _updateList();
    _controller.addListener(_updateList);
  }

  void _updateList() {
    if (!mounted) return;
    setState(() {
      if (_isSearching && _searchController.text.isNotEmpty) {
        _displayedList = _controller.search(_searchController.text);
      } else {
        _displayedList = _controller.filterByCategory(_selectedCategory);
      }
    });
  }

  @override
  void dispose() {
    _controller.removeListener(_updateList);
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categories = TourismController.allCategories;

    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Column(
        children: [
          // ── Header ───────────────────────────────────────────────────
          Container(
            width: double.infinity,
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 12,
              bottom: 16,
              left: 20,
              right: 20,
            ),
            decoration: const BoxDecoration(
              color: _primary,
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                bottomRight: Radius.circular(30),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // top row
                Row(
                  children: [
                    if (widget.showBackButton)
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          width: 38,
                          height: 38,
                          margin: const EdgeInsets.only(right: 12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.arrow_back_ios_new_rounded,
                              color: const Color(0xFF161616), size: 16),
                        ),
                      ),
                    Expanded(
                      child: _isSearching
                          ? TextField(
                              controller: _searchController,
                              autofocus: true,
                              style: GoogleFonts.dmSans(
                                  color: const Color(0xFF161616), fontSize: 16),
                              decoration: InputDecoration(
                                hintText: 'Search destinations…',
                                hintStyle: GoogleFonts.dmSans(
                                    color: Colors.white60, fontSize: 14),
                                border: InputBorder.none,
                              ),
                              onChanged: (_) => _updateList(),
                            )
                          : Text(
                              'Explore',
                              style: GoogleFonts.cormorantGaramond(
                                color: const Color(0xFF161616),
                                fontSize: 26,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          _isSearching = !_isSearching;
                          if (!_isSearching) {
                            _searchController.clear();
                            _updateList();
                          }
                        });
                      },
                      child: Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          _isSearching
                              ? Icons.close_rounded
                              : Icons.search_rounded,
                          color: const Color(0xFF161616),
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                // category chips
                SizedBox(
                  height: 36,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: categories.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      final cat = categories[index];
                      final isSelected = _selectedCategory == cat.id;
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedCategory = cat.id;
                            _isSearching = false;
                            _searchController.clear();
                            _updateList();
                          });
                        },
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? Colors.white
                                : Colors.white.withOpacity(0.18),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(cat.icon,
                                  style: const TextStyle(fontSize: 13)),
                              const SizedBox(width: 5),
                              Text(
                                cat.name,
                                style: GoogleFonts.dmSans(
                                  color: isSelected
                                      ? _primary
                                      : const Color(0xFF161616),
                                  fontWeight: isSelected
                                      ? FontWeight.w700
                                      : FontWeight.w500,
                                  fontSize: 12,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),

          // ── Result count ─────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
            child: Row(
              children: [
                Text(
                  '${_displayedList.length} destination${_displayedList.length != 1 ? 's' : ''} found',
                  style: GoogleFonts.dmSans(
                      color: const Color(0xFF888888), fontSize: 13),
                ),
              ],
            ),
          ),

          // ── List ─────────────────────────────────────────────────────
          Expanded(
            child: _displayedList.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('🔍', style: TextStyle(fontSize: 48)),
                        const SizedBox(height: 12),
                        Text(
                          'No destinations found',
                          style: GoogleFonts.dmSans(
                              color: const Color(0xFF666666), fontSize: 15),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                    itemCount: _displayedList.length,
                    itemBuilder: (context, index) {
                      final dest = _displayedList[index];
                      return _ExploreTile(
                        destination: dest,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DetailsScreen(destination: dest),
                          ),
                        ),
                        onSaveToggle: () => _controller.toggleSaved(dest.id),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _ExploreTile extends StatelessWidget {
  final DestinationModel destination;
  final VoidCallback onTap;
  final VoidCallback onSaveToggle;

  const _ExploreTile({
    required this.destination,
    required this.onTap,
    required this.onSaveToggle,
  });

  static const Color _primary = Color(0xFFD4AF37);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: const Color(0xFF161616),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 16,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // image
            Stack(
              children: [
                ClipRRect(
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(20)),
                  child: Image.network(
                    destination.networkImage,
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 180,
                      color: const Color(0xFF1E1E1E),
                      child: const Icon(Icons.broken_image,
                          size: 48, color: const Color(0xFF666666)),
                    ),
                    loadingBuilder: (_, child, progress) {
                      if (progress == null) return child;
                      return Container(
                        height: 180,
                        color: const Color(0xFF141414),
                        child: const Center(
                            child: CircularProgressIndicator(
                                color: Color(0xFFD4AF37))),
                      );
                    },
                  ),
                ),
                // category badge
                Positioned(
                  top: 12,
                  left: 12,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: _primary.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      destination.category,
                      style: GoogleFonts.dmSans(
                        color: const Color(0xFF161616),
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
                // save button
                Positioned(
                  top: 10,
                  right: 10,
                  child: GestureDetector(
                    onTap: onSaveToggle,
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: const BoxDecoration(
                        color: const Color(0xFF161616),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        destination.isSaved
                            ? Icons.favorite_rounded
                            : Icons.favorite_border_rounded,
                        color: destination.isSaved
                            ? const Color(0xFFFFD700)
                            : Colors.grey,
                        size: 18,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            // info
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(
                          destination.name,
                          style: GoogleFonts.cormorantGaramond(
                            fontSize: 19,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFFF5F0E8),
                          ),
                        ),
                      ),
                      Row(
                        children: [
                          const Icon(Icons.star_rounded,
                              color: Color(0xFFFFD700), size: 15),
                          const SizedBox(width: 3),
                          Text(
                            destination.rating.toString(),
                            style: GoogleFonts.dmSans(
                                fontWeight: FontWeight.w600,
                                fontSize: 13,
                                color: const Color(0xFFF5F0E8)),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.location_on_rounded,
                          color: _primary, size: 14),
                      const SizedBox(width: 3),
                      Text(
                        destination.country,
                        style: GoogleFonts.dmSans(
                            color: const Color(0xFF888888), fontSize: 13),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    destination.description,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: GoogleFonts.dmSans(
                      color: const Color(0xFF999999),
                      fontSize: 13,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(Icons.wb_sunny_outlined,
                          size: 13, color: Color(0xFFFFD700)),
                      const SizedBox(width: 4),
                      Text(
                        'Best: ${destination.bestTime}',
                        style: GoogleFonts.dmSans(
                            fontSize: 12, color: const Color(0xFF888888)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
