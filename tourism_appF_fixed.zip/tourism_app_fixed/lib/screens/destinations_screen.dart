import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../controllers/tourism_controller.dart';
import '../models/destination_model.dart';
import '../widgets/destination_card.dart';
import 'details_screen.dart';

class DestinationsScreen extends StatefulWidget {
  final String initialCategory;
  // FIX #4: new flag so the screen shows a back button when pushed from Home
  final bool showBackButton;

  const DestinationsScreen({
    super.key,
    this.initialCategory = 'all',
    this.showBackButton = false,
  });

  @override
  State<DestinationsScreen> createState() => _DestinationsScreenState();
}

class _DestinationsScreenState extends State<DestinationsScreen> {
  late String _selectedCategory;
  List<DestinationModel> _displayedList = [];
  final TextEditingController _searchController = TextEditingController();
  bool _isSearching = false;
  final _controller = TourismController();

  @override
  void initState() {
    super.initState();
    _selectedCategory = widget.initialCategory;
    _updateList();
    // FIX #1 & #3: listen to controller changes so the list refreshes
    // when a save/unsave happens (e.g. from the Saved tab or Details screen)
    _controller.addListener(_updateList);
  }

  void _updateList() {
    if (!mounted) return;
    setState(() {
      if (_isSearching && _searchController.text.isNotEmpty) {
        _displayedList = _controller.search(_searchController.text);
      } else {
        _displayedList = _controller.filterByCategory(_selectedCategory);
      }
    });
  }

  @override
  void dispose() {
    _controller.removeListener(_updateList);
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final categories = TourismController.allCategories;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FE),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A1A2E),
        // FIX #4: show back button only when pushed as a route from Home
        automaticallyImplyLeading: widget.showBackButton,
        leading: widget.showBackButton
            ? IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              )
            : null,
        title: _isSearching
            ? TextField(
                controller: _searchController,
                autofocus: true,
                style: const TextStyle(color: Colors.white),
                decoration: const InputDecoration(
                  hintText: 'Search destinations...',
                  hintStyle: TextStyle(color: Colors.white54),
                  border: InputBorder.none,
                ),
                onChanged: (_) => _updateList(),
              )
            : Text(
                'All Destinations',
                style: GoogleFonts.playfairDisplay(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
        actions: [
          IconButton(
            icon: Icon(_isSearching ? Icons.close : Icons.search,
                color: Colors.white),
            onPressed: () {
              setState(() {
                _isSearching = !_isSearching;
                if (!_isSearching) {
                  _searchController.clear();
                  _updateList();
                }
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: SizedBox(
              height: 45,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                itemCount: categories.length,
                itemBuilder: (context, index) {
                  final cat = categories[index];
                  final isSelected = _selectedCategory == cat.id;
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        _selectedCategory = cat.id;
                        _isSearching = false;
                        _searchController.clear();
                        _updateList();
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: isSelected
                            ? const Color(0xFF1A1A2E)
                            : Colors.grey[100],
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isSelected
                              ? const Color(0xFF1A1A2E)
                              : Colors.grey.shade300,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(cat.icon, style: const TextStyle(fontSize: 14)),
                          const SizedBox(width: 5),
                          Text(
                            cat.name,
                            style: GoogleFonts.poppins(
                              color:
                                  isSelected ? Colors.white : Colors.grey[700],
                              fontWeight: isSelected
                                  ? FontWeight.w600
                                  : FontWeight.normal,
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Row(
              children: [
                Text(
                  '${_displayedList.length} destination${_displayedList.length != 1 ? 's' : ''} found',
                  style: GoogleFonts.poppins(
                    color: Colors.grey,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _displayedList.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text('🔍', style: TextStyle(fontSize: 50)),
                        const SizedBox(height: 12),
                        Text(
                          'No destinations found',
                          style: GoogleFonts.poppins(
                              color: Colors.grey, fontSize: 16),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _displayedList.length,
                    padding: const EdgeInsets.only(bottom: 20),
                    itemBuilder: (context, index) {
                      final dest = _displayedList[index];
                      return DestinationCard(
                        destination: dest,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => DetailsScreen(destination: dest),
                            ),
                          );
                          // No need for .then() — controller notifyListeners handles refresh
                        },
                        onSaveToggle: () {
                          _controller.toggleSaved(dest.id);
                          // _updateList() is called automatically via listener
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
