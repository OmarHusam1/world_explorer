class DestinationModel {
  final int id;
  final String name;
  final String country;
  final String description;
  final String fullDescription;
  final String imageAsset;
  final String networkImage;
  final String category;
  final double rating;
  final String bestTime;
  final String mapUrl;
  bool isSaved;

  DestinationModel({
    required this.id,
    required this.name,
    required this.country,
    required this.description,
    required this.fullDescription,
    required this.imageAsset,
    required this.networkImage,
    required this.category,
    required this.rating,
    required this.bestTime,
    required this.mapUrl,
    this.isSaved = false,
  });

  String get fullLocation => '$name, $country';

  String get ratingStars {
    int full = rating.floor();
    return '⭐' * full;
  }
}
